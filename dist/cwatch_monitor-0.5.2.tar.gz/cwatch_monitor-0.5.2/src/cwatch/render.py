"""
cwatch.render
~~~~~~~~~~~~~
Terminal rendering: ANSI bars, colors, full-screen dashboard, one-liner.
All display logic lives here — clean separation from fetch/parse logic.
"""

from __future__ import annotations

import os
import platform
import sys
from datetime import datetime
from typing import Optional

from .api import FIVE_HOUR_SECS, PLAN_LIMITS, SEVEN_DAY_SECS, UsageData, Window, _COST_PER_TOKEN

# ─── ANSI codes ───────────────────────────────────────────────────────────────

RESET  = "\033[0m"
BOLD   = "\033[1m"
DIM    = "\033[2m"
BLINK  = "\033[5m"
RED    = "\033[91m"
YELLOW = "\033[93m"
GREEN  = "\033[92m"
CYAN   = "\033[96m"
WHITE  = "\033[97m"
BLUE   = "\033[94m"
ORANGE = "\033[38;5;208m"


def sys_supports_color() -> bool:
    if platform.system() == "Windows":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32  # type: ignore
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
            return True
        except Exception:
            return False
    return True


_NO_COLOR = os.environ.get("NO_COLOR") or not sys_supports_color()


def _c(code: str, text: str) -> str:
    if _NO_COLOR:
        return text
    return f"{code}{text}{RESET}"


# ─── Building blocks ──────────────────────────────────────────────────────────

def _color_for(pct: int) -> str:
    if pct >= 90:
        return RED
    if pct >= 80:
        return ORANGE
    if pct >= 60:
        return YELLOW
    if pct >= 40:
        return CYAN
    return GREEN


def _alert_suffix(pct: int) -> str:
    """Return a visual alert indicator for high usage."""
    if pct >= 90:
        return f"  {_c(BOLD + RED, 'CRIT')}"
    if pct >= 80:
        return f"  {_c(BOLD + ORANGE, 'WARN')}"
    return ""


def bar(pct: int, width: int = 25, colored: bool = True, color: Optional[str] = None) -> str:
    """Return a filled progress bar string."""
    filled     = round(pct / 100 * width)
    empty      = width - filled
    fill_char  = "█"
    empty_char = "░"
    if colored and not _NO_COLOR:
        c     = color or _color_for(pct)
        blink = BLINK if pct >= 90 else ""
        return f"{blink}{c}{fill_char * filled}{RESET}{DIM}{empty_char * empty}{RESET}"
    return fill_char * filled + empty_char * empty


def _window_block(
    label: str,
    w: Optional[Window],
    total_seconds: int,
    bar_width: int = 25,
    show_eta: bool = False,
) -> list[str]:
    """Return lines for one usage window (usage bar + time bar)."""
    if w is None:
        return [f"  {_c(DIM, label + ':'):22s}  {_c(DIM, 'no data')}"]

    pct     = w.pct
    b_usage = bar(pct, bar_width)
    c       = _color_for(pct)

    if w.resets_at:
        reset_at   = w.resets_at.astimezone().strftime("%H:%M:%S")
        reset_info = f"reset in {w.time_until_reset}  ({reset_at})"
    else:
        reset_info = "reset time pending"

    # ── usage line ────────────────────────────────────────────────────────────
    usage_line = (
        f"  [{b_usage}]  {_c(c, f'{pct:3d}%')}{_alert_suffix(pct)}  "
        f"{_c(DIM, reset_info)}"
    )

    # ── time bar line ─────────────────────────────────────────────────────────
    elapsed = w.elapsed_pct(total_seconds)
    time_line = ""
    if elapsed is not None:
        b_time = bar(elapsed, bar_width, colored=True, color=BLUE)
        eta_part = ""
        if show_eta:
            end_clock = w.predicted_end_clock(total_seconds)
            eta       = w.eta_str(total_seconds)
            if end_clock:
                eta_part = f"  {_c(YELLOW, f'limit ~{end_clock}  ({eta} from now)')}"
            elif eta:
                eta_part = f"  {_c(YELLOW, f'limit in {eta} at this rate')}"
        elapsed_str = _c(DIM, f"{elapsed:3d}%  time elapsed")
        time_line = f"  [{b_time}]  {elapsed_str}{eta_part}"

    lines = [f"  {_c(BOLD, label)}", usage_line]
    if time_line:
        lines.append(time_line)
    return lines


# ─── Output modes ─────────────────────────────────────────────────────────────

def oneliner(data: UsageData) -> str:
    """
    Compact single line — good for tmux statusline or scripting.
    Example:  Claude [████████░░░░░░░░░░░░░░░░░] 32%  7d:18%
    """
    parts = []
    if data.five_hour:
        pct = data.five_hour.pct
        b   = bar(pct, 10)
        parts.append(f"Claude [{b}] {pct}%")
    if data.seven_day:
        parts.append(f"7d:{data.seven_day.pct}%")
    return "  ".join(parts) if parts else "Claude: no data"


_TIPS = [
    "Use /clear between unrelated tasks to reset context",
    "Reference specific files instead of whole directories",
    "Keep questions focused — one task at a time",
    "Use CLAUDE.md to avoid repeating instructions every session",
    "Paste only relevant code snippets, not entire files",
]

_LINES_PER_TOKEN  = 0.10    # 1 token ≈ 10 chars ≈ 0.1 lines of code


def _token_insights(data: UsageData, plan_key: str) -> list[str]:
    """Return lines for the token insights section."""
    w = data.five_hour
    if w is None or plan_key not in PLAN_LIMITS:
        return []

    limit      = PLAN_LIMITS[plan_key]
    used       = round(w.utilization / 100 * limit)
    lines_est  = round(used * _LINES_PER_TOKEN)
    cost_est   = used * _COST_PER_TOKEN
    tip_index  = used % len(_TIPS)

    sep   = _c(CYAN, "─" * 60)
    plan_label = {"pro": "Pro · 88k/5h", "max5": "Max 5x · 440k/5h", "max20": "Max 20x · 1.76M/5h"}[plan_key]

    used_str  = f"{used:,}"
    limit_str = f"{limit // 1000}k" if limit < 1_000_000 else f"{limit / 1_000_000:.1f}M"
    cost_str  = f"${cost_est:.2f}"
    lines_str = f"~{lines_est:,} lines of code"

    end_clock = w.predicted_end_clock(FIVE_HOUR_SECS)
    end_str   = f"   session ends ~{_c(YELLOW, end_clock)}" if end_clock else ""

    return [
        "",
        sep,
        f"  {_c(BOLD + CYAN, 'TOKEN INSIGHTS'):<40s}  {_c(DIM, plan_label)}",
        sep,
        "",
        f"  {_c(BOLD, 'Used:')}   {_c(GREEN, used_str)} / {limit_str} tokens"
        f"   {_c(DIM, '≈ ' + lines_str + '   ≈ ' + cost_str)}{end_str}",
        "",
        f"  {_c(BOLD, 'Tip:')}    {_c(DIM, _TIPS[tip_index])}",
        "",
    ]


def _plan_key(data: UsageData, override: str = "") -> str:
    """Resolve plan key for token limit lookup."""
    if override:
        return override
    p = data.plan.lower()
    if "pro" in p:
        return "pro"
    if "20" in p:
        return "max20"
    if "max" in p:
        return "max5"   # default for Max without tier info
    return ""


def dashboard(data: UsageData, updated_at: Optional[datetime] = None, plan_override: str = "") -> str:
    """Full-screen dashboard string."""
    sep   = _c(CYAN, "─" * 60)
    plan  = _c(BOLD, data.plan)
    title = _c(BOLD + CYAN, "CLAUDE CODE  ·  USAGE MONITOR")

    lines: list[str] = [
        "",
        sep,
        f"  {title:<40s}  {plan}",
        sep,
        "",
    ]

    lines += _window_block("5-hour session", data.five_hour,  FIVE_HOUR_SECS, show_eta=True)
    lines += [""]
    lines += _window_block("7-day window  ", data.seven_day,  SEVEN_DAY_SECS)

    if data.seven_day_opus and data.seven_day_opus.utilization > 0:
        lines += [""]
        lines += _window_block("Opus (weekly) ", data.seven_day_opus, SEVEN_DAY_SECS)

    pk = _plan_key(data, plan_override)
    if pk:
        lines += _token_insights(data, pk)
    else:
        lines += [""]

    lines += [sep]

    ts = (updated_at or datetime.now()).strftime("%H:%M:%S")
    lines.append(f"  {_c(DIM, f'Updated {ts}')}")
    lines.append("")

    return "\n".join(lines)


def status_line(countdown: int, interval: int, bell_on: bool = False) -> str:
    """Updatable one-line status bar shown below the dashboard."""
    bell  = "[b]bell:ON " if bell_on else "[b]bell    "
    keys  = f"[r]refresh  [+/-]interval  {bell}[t]title  [q]quit"
    timer = f"Next refresh in {countdown}s"
    return f"  {_c(DIM, timer + '   ·   ' + keys)}"


def stats_str() -> str:
    """Return a formatted stats block string."""
    from .history import stats
    s   = stats()
    sep = _c(CYAN, "─" * 60)

    if not s:
        return (
            f"\n  {sep}\n"
            f"  {_c(BOLD + CYAN, 'USAGE STATS')}\n"
            f"  {sep}\n\n"
            f"  No history yet — run cwatch for a while to collect data.\n\n"
        )

    peak_hour_str = f"{s['peak_hour']:02d}:00" if s["peak_hour"] is not None else "unknown"
    lines = [
        "",
        sep,
        f"  {_c(BOLD + CYAN, 'USAGE STATS')}",
        sep,
        "",
        f"  {_c(BOLD, 'Today:')}        avg {s['today_avg']:3d}%   peak {s['today_peak']:3d}%   ({s['today_count']} readings)",
        f"  {_c(BOLD, 'Yesterday:')}    avg {s['yesterday_avg']:3d}%   peak {s['yesterday_peak']:3d}%",
        "",
        f"  {_c(BOLD, 'All time:')}     avg {s['avg_pct']:3d}%   peak {s['peak_pct']:3d}%   ({s['total']} readings)",
        f"  {_c(BOLD, 'Over 80%:')}     {s['times_80']} times",
        f"  {_c(BOLD, 'Over 90%:')}     {s['times_90']} times",
        f"  {_c(BOLD, 'Peak hour:')}    {peak_hour_str}",
        "",
        sep,
        "",
    ]
    return "\n".join(lines)


def set_terminal_title(data: UsageData) -> None:
    """Update the terminal window/tab title with current usage."""
    parts = []
    if data.five_hour:
        parts.append(f"5h:{data.five_hour.pct}%")
    if data.seven_day:
        parts.append(f"7d:{data.seven_day.pct}%")
    title = "Claude " + "  ".join(parts) if parts else "Claude"
    sys.stdout.write(f"\033]0;{title}\007")
    sys.stdout.flush()


def clear_screen() -> None:
    """Full clear — only on first draw or forced refresh."""
    if platform.system() == "Windows":
        os.system("cls")
    else:
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


def cursor_home() -> None:
    """Move cursor to top-left without erasing — for tick redraws (no flicker)."""
    if platform.system() == "Windows":
        os.system("cls")
    else:
        sys.stdout.write("\033[H")
        sys.stdout.flush()
